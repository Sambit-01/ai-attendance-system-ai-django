# attendance/utils.py
import cv2
import numpy as np
from datetime import datetime
from insightface.app import FaceAnalysis
import pandas as pd
import os
import albumentations
import pickle
import base64
from sklearn.metrics.pairwise import cosine_similarity

app = FaceAnalysis()
app.prepare(ctx_id=-1, det_size=(640, 640))  

# def find_embedding(img_path): # Type: Image path
#     img = cv2.imread(img_path)
#     faces = app.get(img)
#     if len(faces) > 0:
#         return faces[0].embedding  
#     else:
#         return None

def capture_frame_from_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return None, "Unable to access the webcam. Please check your setup."
    
    ret, frame = cap.read()  # Capture a single frame
    if not ret:
        cap.release()
        return None, "Failed to capture a frame from the webcam."
    
    cap.release()
    return frame, None

def find_embedding_from_array(img):
    faces = app.get(img)
    embedding = faces[0].embedding  
    return embedding

employee_file = 'D:\\JITU\\CODE DAIS\\AI Attendance System\\AI_Attendance_django\\employees.csv'

def recognize_person_from_csv(face_embedding, cosine_threshold=0.7, euclidean_threshold=20):
    try:
        df = pd.read_csv(employee_file)
    except FileNotFoundError:
        print("Employee database not found.")
        return None, None

    for _, row in df.iterrows():
        stored_embedding = pickle.loads(base64.b64decode(row['Embedding']))

        euclidean_distance = np.linalg.norm(face_embedding - stored_embedding)

        cosine_sim = cosine_similarity([face_embedding], [stored_embedding])[0][0]

        if cosine_sim > cosine_threshold or euclidean_distance < euclidean_threshold:
            return row['Name'], row['Employee_ID']

    return None, None

from datetime import datetime

attendance_file = 'D:\\JITU\\CODE DAIS\\AI Attendance System\\AI_Attendance_django\\attendance_log.xlsx'

try:
    pd.read_excel(attendance_file)
except FileNotFoundError:
    columns = ['Employee_ID', 'Name', 'Timestamp']
    pd.DataFrame(columns=columns).to_excel(attendance_file, index=False)

def record_attendance_in_excel(employee_id, name):
    df = pd.read_excel(attendance_file)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_data = {'Employee_ID': employee_id, 'Name': name, 'Timestamp': timestamp}
    df = pd.concat([df, pd.DataFrame([new_data])], ignore_index=True)

    df.to_excel(attendance_file, index=False)
    print(f"Attendance recorded for {name} at {timestamp}.")