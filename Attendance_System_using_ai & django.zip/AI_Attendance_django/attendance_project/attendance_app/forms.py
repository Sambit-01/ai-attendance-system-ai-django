# attendance/forms.py
from django import forms

class AttendanceForm(forms.Form):
    photo = forms.ImageField(label='Upload your photo', required=True)
