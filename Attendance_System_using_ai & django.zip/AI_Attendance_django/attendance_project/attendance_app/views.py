from django.shortcuts import render
from .utils import (
    find_embedding_from_array,
    recognize_person_from_csv,
    record_attendance_in_excel,
)
import numpy as np
from datetime import datetime
import base64
import os
from PIL import Image
from django.conf import settings
from django.http import JsonResponse
from django.http import HttpResponse
from PIL import Image
import io
from django.core.files.storage import default_storage


SAVE_DIR = 'captured_images/'


def camera_view(request):
    return render(request, 'attendance_app/attendance_form.html')

def attendance(request):
    print('i am here 0')
    if request.method == 'POST':
        image_data = request.POST.get('image')
        print('i am here 1')

        if image_data:
            print('i am here 2')
            try:
                # Decode the base64 image
                image_data = image_data.split(',')[1]
                image_data = base64.b64decode(image_data)
                print('i am here 3')

                # Save the image with a unique name
                if not os.path.exists(SAVE_DIR):
                    os.makedirs(SAVE_DIR)

                file_name = f"{SAVE_DIR}image_{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
                with open(file_name, 'wb') as f:
                    f.write(image_data)

                # Open and process the saved image
                img = Image.open(io.BytesIO(image_data))
                img1 = img.convert('RGB')
                img_np = np.array(img1)

                # Find embedding
                embedding = find_embedding_from_array(img_np)

                if embedding is not None:
                    # Recognize the person
                    name, employee_id = recognize_person_from_csv(embedding)
                    print('i am here 4')

                    if name:
                        # Record attendance
                        record_attendance_in_excel(employee_id, name)
                        print('i am here 5')
                        context = {
                            'name': name,
                            'employee_id': employee_id,
                            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        }
                        return render(request, 'attendance_app/recognition_result.html', context)
                    else:
                        return render(request, 'attendance_app/recognition_result.html', {
                            'error_message': 'No match found for the uploaded image.'
                        })
                else:
                    return render(request, 'attendance_app/recognition_result.html', {
                        'error_message': 'Unable to extract embeddings. Please try again with a clearer image.'
                    })

            except Exception as e:
                return render(request, 'attendance_app/recognition_result.html', {
                    'error_message': f'An error occurred: {str(e)}'
                })
        else:
            return render(request, 'attendance_app/recognition_result.html', {
                'error_message': 'No image data provided.'
            })

    print('i am here 6')
    # Render the attendance form if not a POST request
    return render(request, 'attendance_app/attendance_form.html')


